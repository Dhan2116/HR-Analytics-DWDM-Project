-- ============================================================
-- ❄️ SNOWFLAKE ENTERPRISE HR ANALYTICS & DATA RECOVERY PLATFORM
-- ============================================================
-- Project goals:
-- 1. Environment setup
-- 2. HR data creation and loading
-- 3. CRUD operations
-- 4. Data-quality validation
-- 5. Analytical views and KPIs
-- 6. Time Travel
-- 7. Controlled data recovery
-- 8. Audit trail
-- ============================================================

-- ============================================================
-- MODULE 1 — CONNECTION & ENVIRONMENT VERIFICATION
-- ============================================================

SELECT 'MODULE 1 - CONNECTION VERIFICATION' AS MODULE;

SELECT
    CURRENT_USER()       AS CURRENT_USER,
    CURRENT_ROLE()       AS CURRENT_ROLE,
    CURRENT_WAREHOUSE()  AS CURRENT_WAREHOUSE,
    CURRENT_DATABASE()   AS CURRENT_DATABASE,
    CURRENT_SCHEMA()     AS CURRENT_SCHEMA;

-- ============================================================
-- MODULE 2 — CLOUD DATA PLATFORM SETUP
-- ============================================================

SELECT 'MODULE 2 - PLATFORM SETUP' AS MODULE;

CREATE OR REPLACE DATABASE HR_ANALYTICS_DB;

CREATE OR REPLACE SCHEMA HR_ANALYTICS_DB.CORE;

CREATE OR REPLACE WAREHOUSE HR_ANALYTICS_WH
    WAREHOUSE_SIZE = XSMALL
    AUTO_SUSPEND = 300
    AUTO_RESUME = TRUE
    INITIALLY_SUSPENDED = TRUE;

USE DATABASE HR_ANALYTICS_DB;
USE SCHEMA CORE;
USE WAREHOUSE HR_ANALYTICS_WH;

CREATE OR REPLACE STAGE HR_STAGE;

SHOW DATABASES LIKE 'HR_ANALYTICS%';
SHOW SCHEMAS IN DATABASE HR_ANALYTICS_DB;
SHOW WAREHOUSES LIKE 'HR_ANALYTICS%';
SHOW STAGES IN SCHEMA HR_ANALYTICS_DB.CORE;

-- ============================================================
-- MODULE 3 — HR DATA MODEL
-- ============================================================

SELECT 'MODULE 3 - DATA MODEL' AS MODULE;

CREATE OR REPLACE TABLE employees (
    emp_id          INTEGER PRIMARY KEY,
    emp_name        VARCHAR(100) NOT NULL,
    department      VARCHAR(50) NOT NULL,
    job_title       VARCHAR(100),
    salary          DECIMAL(12,2),
    joining_date    DATE,
    employment_type VARCHAR(30),
    location        VARCHAR(80),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

CREATE OR REPLACE TABLE operation_audit (
    audit_id        INTEGER AUTOINCREMENT,
    operation_type  VARCHAR(30),
    affected_table  VARCHAR(100),
    affected_emp_id INTEGER,
    operation_time  TIMESTAMP DEFAULT CURRENT_TIMESTAMP(),
    notes           VARCHAR(500)
);

-- ============================================================
-- MODULE 4 — INITIAL DATA LOAD
-- ============================================================

SELECT 'MODULE 4 - INITIAL DATA LOAD' AS MODULE;

INSERT INTO employees
(emp_id, emp_name, department, job_title, salary, joining_date, employment_type, location)
VALUES
(101, 'John Doe',        'Engineering', 'Software Engineer',     75000, '2023-01-15', 'Full-Time', 'Chennai'),
(102, 'Jane Smith',      'Marketing',   'Marketing Specialist',  65000, '2023-02-20', 'Full-Time', 'Bengaluru'),
(103, 'Bob Johnson',     'Engineering', 'Senior Engineer',       85000, '2023-03-10', 'Full-Time', 'Hyderabad'),
(104, 'Alice Brown',     'Sales',       'Sales Executive',       70000, '2023-04-05', 'Full-Time', 'Chennai'),
(105, 'Charlie Wilson',  'HR',          'HR Executive',           55000, '2023-05-12', 'Full-Time', 'Pune'),
(106, 'David Lee',       'IT',          'Cloud Engineer',         80000, '2023-06-01', 'Full-Time', 'Bengaluru'),
(107, 'Sarah Connor',    'Finance',     'Financial Analyst',     82000, '2023-07-15', 'Full-Time', 'Mumbai'),
(108, 'Mike Ross',       'Legal',       'Legal Associate',       90000, '2023-08-20', 'Full-Time', 'Delhi'),
(109, 'Rachel Zane',     'Marketing',   'Brand Analyst',          68000, '2023-09-10', 'Full-Time', 'Bengaluru'),
(110, 'Harvey Specter',  'Legal',       'Senior Legal Counsel',   95000, '2023-10-05', 'Full-Time', 'Delhi'),
(111, 'Louis Litt',      'Finance',     'Finance Manager',        72000, '2023-11-12', 'Full-Time', 'Mumbai'),
(112, 'Emma Stone',      'Engineering', 'Data Engineer',          88000, '2024-01-08', 'Full-Time', 'Chennai'),
(113, 'Liam Brown',      'IT',          'DevOps Engineer',         83000, '2024-02-14', 'Full-Time', 'Hyderabad'),
(114, 'Olivia Davis',    'HR',          'Recruitment Specialist', 62000, '2024-03-18', 'Full-Time', 'Pune'),
(115, 'Noah Wilson',     'Sales',       'Account Manager',        76000, '2024-04-22', 'Full-Time', 'Chennai');

SELECT 'INITIAL EMPLOYEE DATA' AS STEP, *
FROM employees
ORDER BY emp_id;

SELECT COUNT(*) AS total_employees
FROM employees;

-- ============================================================
-- MODULE 5 — CRUD OPERATIONS
-- ============================================================

SELECT 'MODULE 5 - CRUD OPERATIONS' AS MODULE;

-- CREATE / INSERT
INSERT INTO employees
(emp_id, emp_name, department, job_title, salary, joining_date, employment_type, location)
VALUES
(116, 'Daniel Kim', 'IT', 'Cloud Architect', 97000, '2024-05-10', 'Full-Time', 'Bengaluru');

INSERT INTO operation_audit
(operation_type, affected_table, affected_emp_id, notes)
VALUES
('INSERT', 'EMPLOYEES', 116, 'New employee added for CRUD demonstration');

-- READ
SELECT *
FROM employees
WHERE emp_id = 116;

-- UPDATE
UPDATE employees
SET salary = salary * 1.10
WHERE department = 'Engineering';

INSERT INTO operation_audit
(operation_type, affected_table, notes)
VALUES
('UPDATE', 'EMPLOYEES', '10% salary revision applied to Engineering department');

-- DELETE
DELETE FROM employees
WHERE emp_id = 116;

INSERT INTO operation_audit
(operation_type, affected_table, affected_emp_id, notes)
VALUES
('DELETE', 'EMPLOYEES', 116, 'Test employee deleted for recovery demonstration');

SELECT 'POST-CRUD STATE' AS STEP, *
FROM employees
ORDER BY emp_id;

-- ============================================================
-- MODULE 6 — DATA QUALITY & VALIDATION
-- ============================================================

SELECT 'MODULE 6 - DATA QUALITY' AS MODULE;

-- Check for duplicate employee IDs
SELECT emp_id, COUNT(*) AS duplicate_count
FROM employees
GROUP BY emp_id
HAVING COUNT(*) > 1;

-- Check for missing critical attributes
SELECT *
FROM employees
WHERE emp_name IS NULL
   OR department IS NULL
   OR salary IS NULL
   OR joining_date IS NULL;

-- Check for invalid salary values
SELECT *
FROM employees
WHERE salary <= 0;

-- Check department distribution
SELECT
    department,
    COUNT(*) AS employee_count
FROM employees
GROUP BY department
ORDER BY employee_count DESC;

-- ============================================================
-- MODULE 7 — ANALYTICAL VIEWS
-- ============================================================

SELECT 'MODULE 7 - ANALYTICAL VIEWS' AS MODULE;

CREATE OR REPLACE VIEW vw_department_kpis AS
SELECT
    department,
    COUNT(*) AS headcount,
    ROUND(AVG(salary), 2) AS average_salary,
    ROUND(MIN(salary), 2) AS minimum_salary,
    ROUND(MAX(salary), 2) AS maximum_salary,
    ROUND(SUM(salary), 2) AS total_salary_cost
FROM employees
GROUP BY department;

CREATE OR REPLACE VIEW vw_salary_bands AS
SELECT
    emp_id,
    emp_name,
    department,
    salary,
    CASE
        WHEN salary < 60000 THEN 'Entry'
        WHEN salary < 80000 THEN 'Mid'
        WHEN salary < 90000 THEN 'Senior'
        ELSE 'Leadership / Specialist'
    END AS salary_band
FROM employees;

CREATE OR REPLACE VIEW vw_employee_tenure AS
SELECT
    emp_id,
    emp_name,
    department,
    joining_date,
    DATEDIFF('month', joining_date, CURRENT_DATE()) AS tenure_months,
    ROUND(DATEDIFF('month', joining_date, CURRENT_DATE()) / 12.0, 1) AS tenure_years
FROM employees;

-- ============================================================
-- MODULE 8 — MANAGEMENT KPI QUERIES
-- ============================================================

SELECT 'MODULE 8 - MANAGEMENT KPIs' AS MODULE;

-- KPI 1: Overall headcount
SELECT COUNT(*) AS total_headcount
FROM employees;

-- KPI 2: Average salary
SELECT ROUND(AVG(salary), 2) AS average_salary
FROM employees;

-- KPI 3: Department KPIs
SELECT *
FROM vw_department_kpis
ORDER BY headcount DESC, average_salary DESC;

-- KPI 4: Salary bands
SELECT
    salary_band,
    COUNT(*) AS employee_count
FROM vw_salary_bands
GROUP BY salary_band
ORDER BY employee_count DESC;

-- KPI 5: Highest-paid employees
SELECT
    emp_id,
    emp_name,
    department,
    job_title,
    salary
FROM employees
ORDER BY salary DESC
LIMIT 5;

-- KPI 6: Hiring trend by year
SELECT
    YEAR(joining_date) AS joining_year,
    COUNT(*) AS hires
FROM employees
GROUP BY YEAR(joining_date)
ORDER BY joining_year;

-- KPI 7: Workforce by location
SELECT
    location,
    COUNT(*) AS employee_count
FROM employees
GROUP BY location
ORDER BY employee_count DESC;

-- ============================================================
-- MODULE 9 — TIME TRAVEL DEMONSTRATION
-- ============================================================

SELECT 'MODULE 9 - TIME TRAVEL' AS MODULE;

-- Capture current state before controlled changes.
SELECT
    emp_id,
    emp_name,
    department,
    salary
FROM employees
ORDER BY emp_id;

-- IMPORTANT:
-- Run this section immediately after the preceding query.
-- The offset is intentionally short for demonstration purposes.

UPDATE employees
SET salary = salary * 1.25
WHERE department = 'Finance';

DELETE FROM employees
WHERE emp_id = 104;

INSERT INTO operation_audit
(operation_type, affected_table, affected_emp_id, notes)
VALUES
('UPDATE', 'EMPLOYEES', NULL, 'Controlled Time Travel test: Finance salaries increased by 25%'),
('DELETE', 'EMPLOYEES', 104, 'Controlled Time Travel test: employee 104 deleted');

SELECT 'CURRENT STATE AFTER INCIDENT' AS STEP, *
FROM employees
ORDER BY emp_id;

-- Historical snapshot.
-- Run immediately after the controlled changes.
SELECT
    emp_id,
    emp_name,
    department,
    salary
FROM employees
BEFORE (OFFSET => -60)
ORDER BY emp_id;

-- ============================================================
-- MODULE 10 — DATA RECOVERY
-- ============================================================

SELECT 'MODULE 10 - DATA RECOVERY' AS MODULE;

-- Recover employee 104 from the historical snapshot.
-- The exact offset can be adjusted according to execution timing.

INSERT INTO employees
SELECT *
FROM employees
BEFORE (OFFSET => -60)
WHERE emp_id = 104
  AND NOT EXISTS (
      SELECT 1
      FROM employees e
      WHERE e.emp_id = 104
  );

-- Recover the original Finance salaries from historical state.
-- This demonstrates point-in-time restoration at row level.
UPDATE employees current_emp
SET salary = historical_emp.salary
FROM employees BEFORE (OFFSET => -60) historical_emp
WHERE current_emp.emp_id = historical_emp.emp_id
  AND current_emp.department = 'Finance';

SELECT 'RECOVERED STATE' AS STEP, *
FROM employees
ORDER BY emp_id;

-- ============================================================
-- MODULE 11 — AUDIT REPORT
-- ============================================================

SELECT 'MODULE 11 - AUDIT REPORT' AS MODULE;

SELECT
    audit_id,
    operation_type,
    affected_table,
    affected_emp_id,
    operation_time,
    notes
FROM operation_audit
ORDER BY operation_time, audit_id;

-- ============================================================
-- MODULE 12 — FINAL HEALTH CHECK
-- ============================================================

SELECT 'MODULE 12 - FINAL PLATFORM HEALTH CHECK' AS MODULE;

SELECT
    (SELECT COUNT(*) FROM employees) AS final_employee_count,
    (SELECT COUNT(*) FROM operation_audit) AS audit_event_count;

SELECT
    'No duplicate IDs' AS CHECK_NAME,
    CASE
        WHEN COUNT(*) = 0 THEN 'PASS'
        ELSE 'REVIEW'
    END AS RESULT
FROM (
    SELECT emp_id
    FROM employees
    GROUP BY emp_id
    HAVING COUNT(*) > 1
);

SELECT
    'No invalid salaries' AS CHECK_NAME,
    CASE
        WHEN COUNT(*) = 0 THEN 'PASS'
        ELSE 'REVIEW'
    END AS RESULT
FROM employees
WHERE salary <= 0;

SELECT 'PROJECT EXECUTION COMPLETE' AS FINAL_STATUS;
